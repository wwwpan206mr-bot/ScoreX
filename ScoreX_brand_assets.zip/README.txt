ScoreX brand assets

Files:
- scorex_app_icon_1024.png: 1024x1024 launcher icon source
- scorex_logo_transparent.png: transparent logo for in-app header/home
- scorex_splash_logo.png: transparent splash-screen logo
- scorex_adaptive_foreground.png / scorex_adaptive_background.png: Android adaptive icon layers
- android/mipmap-*/ic_launcher.png: Android launcher icon density variants

Flutter integration:
1. Copy scorex_logo_transparent.png and scorex_splash_logo.png into your Flutter assets folder.
2. Configure launcher icon generation using scorex_app_icon_1024.png, or copy the mipmap folders into android/app/src/main/res/.
3. For adaptive icons, use the foreground and background layers with your existing Android icon configuration.
4. Keep your existing package ID, signing config, Firebase config, and AdMob IDs unchanged.
